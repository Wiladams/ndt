This is a collection of little Windows fidgets
In most cases, you play around by moving the mouse
and hitting some keys on the keyboard.

In some cases, pressing the [Space] bar will change modes
In some cases, pressing "Esc" will change modes, or close the program
In some cases, pressing [UP][DOWN] arrow keys will do something

simchain - move the mouse around, press up/down arrow, press [space], press [ESC]
bannersketch - just watch, click a ball, then press [ESC], [space] will turn into a normal window
compkeyboard - type on regular physical keyboard, watch virtual keys light up, press [ESC] to switch modes
desktoplife - watch, press [SPACE] to reset. click other windows on desktop, click on single cell to restore life, [ESC] to quit
screenplanes - capture section of screen, split it to R,G,B,Gray.  Move it to the right so it's not part of capture
snapview - take a snapshot of your screen and watch it
spirograph - watch it twirl, [SPACE] to see a different view
svgcolors - just mouse around pretty colors
wavemaker - move mouse around, watch pretty patterns


